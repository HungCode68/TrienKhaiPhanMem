// mũi tên chuyển quảng cáo
let currentSlide = 0;

function moveSlide(direction) {
  const slides = document.getElementById("promoSlideContainer");
  const totalSlides = slides.children.length;
  currentSlide += direction;

  if (currentSlide >= totalSlides) {
    currentSlide = 0;
  } else if (currentSlide < 0) {
    currentSlide = totalSlides - 1;
  }

  slides.style.transform = `translateX(-${currentSlide * 100}%)`;
}
//end

//menu
document.addEventListener("DOMContentLoaded", function () {
  const viewMenuButton = document.querySelector(".view-menu");

  //  'Xem thêm thực đơn' button
  viewMenuButton.addEventListener("click", function () {
    window.location.href = "ThucDon.html";
  });
});

document.addEventListener("DOMContentLoaded", function () {
  
  const choiceButtons = document.querySelectorAll(".choice-button");
  const searchButton = document.querySelector(".search-button");

  
  choiceButtons.forEach((button) => {
    button.addEventListener("click", function () {
      toggleActiveButton(button);
      console.log("Bạn đã chọn phương thức giao hàng");
      // Add any other actions for choice buttons here
    });
  });

  searchButton.addEventListener("click", function () {
    toggleActiveButton(searchButton);
    console.log("Search button clicked");
    // Add any other actions for the search button here
  });

  function toggleActiveButton(button) {
    choiceButtons.forEach((btn) => btn.classList.remove("active"));
    searchButton.classList.remove("active");

    button.classList.add("active");

    setTimeout(() => {
      button.classList.remove("active");
    }, 1000); 
  }
});



