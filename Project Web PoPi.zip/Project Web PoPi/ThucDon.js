document.addEventListener("DOMContentLoaded", function () {
  // Select each button
  const choiceButtons = document.querySelectorAll(".choice-button");
  const searchButton = document.querySelector(".search-button");

  // Loop through each choice button to add an event listener
  choiceButtons.forEach((button) => {
    button.addEventListener("click", function () {
      toggleActiveButton(button);
      console.log("Bạn đã chọn phương thức giao hàng");
      // them code duoc nha
    });
  });

  // Add event listener for the search button
  searchButton.addEventListener("click", function () {
    toggleActiveButton(searchButton);
    console.log("Search button clicked");
    // them code duoc nha
  });

  // Function to add the active class to the clicked button and remove it from others
  function toggleActiveButton(button) {
    // Remove the active class from all buttons
    choiceButtons.forEach((btn) => btn.classList.remove("active"));
    searchButton.classList.remove("active");

    // Add the active class to the clicked button
    button.classList.add("active");

    // Set a timeout to remove the active class after 1 second
    setTimeout(() => {
      button.classList.remove("active");
    }, 1000); // 1000 milliseconds = 1 second
  }
});

function openModal() {
  const modal = document.getElementById('orderModal');
  modal.classList.add('show'); // Add the 'show' class to make it visible
}

// Function to close the modal
function closeModal() {
  const modal = document.getElementById('orderModal');
  modal.classList.remove('show'); // Remove the 'show' class to hide the modal
}

// Function to redirect to the cart (example)
function redirectToCart() {
  window.location.href = 'GioHang.html'; // Replace with your cart page URL
}