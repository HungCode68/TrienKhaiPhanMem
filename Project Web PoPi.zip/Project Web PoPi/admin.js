
document.addEventListener("DOMContentLoaded", function() {
    const addProductForm = document.getElementById("add-product-form");
  
    // Xử lý khi thêm sản phẩm mới
    addProductForm.addEventListener("submit", function(event) {
      event.preventDefault();
  
      const productName = document.getElementById("product-name").value;
      const productPrice = document.getElementById("product-price").value;
      const productDescription = document.getElementById("product-description").value;
      const productImage = document.getElementById("product-image").files[0];
  
      if (productName && productPrice && productDescription && productImage) {
        // Mô phỏng thêm sản phẩm thành công (có thể thay thế với việc gửi dữ liệu lên server)
        alert("Thêm sản phẩm thành công!");
  
        // Xóa thông tin trong form sau khi thêm sản phẩm
        addProductForm.reset();
      } else {
        alert("Vui lòng điền đầy đủ thông tin!");
      }
    });
  
    // Quản lý tài khoản người dùng (sửa, xóa)
    document.getElementById('add-account-btn').addEventListener('click', function() {
      // Example: Show a form to add a new account
      alert('Thêm tài khoản mới');
    });

    const deleteButtons = document.querySelectorAll(".delete-account-btn");
    deleteButtons.forEach(button => {
      button.addEventListener("click", function() {
        const row = button.closest("tr");
        row.remove();  // Xóa người dùng khỏi bảng (mô phỏng)
        alert("Đã xóa tài khoản người dùng!");
      });
    });
  
  
    // Đăng xuất
    const logoutButton = document.getElementById("logout-btn");
    logoutButton.addEventListener("click", function() {
      window.location.href = "Home.html";  // Chuyển về trang login hoặc trang chủ
    });
  });
  