
function openModal() {
    const modal = document.getElementById('orderModal');
    modal.classList.add('show'); // Add the 'show' class to make it visible
  }
  
  // Function to close the modal
  function closeModal() {
    const modal = document.getElementById('orderModal');
    modal.classList.remove('show'); // Remove the 'show' class to hide the modal
  }
  
  // Function to redirect to the cart (example)
  function redirectToCart() {
    window.location.href = '/GioHang.html'; // Replace with your cart page URL
  }